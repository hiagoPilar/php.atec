<?php $__env->startSection('title', 'Bicycle Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header bg-info text-white">
                <h2 class="mb-0"><i class="fas fa-bicycle"></i> Bicycle Details</h2>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>ID:</strong> <?php echo e($bicycle->id); ?></p>
                        <p><strong>Brand:</strong> <?php echo e($bicycle->brand); ?></p>
                        <p><strong>Model:</strong> <?php echo e($bicycle->model); ?></p>
                        <p><strong>Color:</strong> <?php echo e($bicycle->color); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Price:</strong> €<?php echo e(number_format($bicycle->price, 2)); ?></p>
                        <p><strong>Owner:</strong> <?php echo e($bicycle->user->name); ?></p>
                        <p><strong>Country:</strong> <?php echo e($bicycle->user->country->name); ?></p>
                        <p><strong>Created:</strong> <?php echo e($bicycle->created_at->format('d/m/Y H:i')); ?></p>
                    </div>
                </div>

                <div class="d-flex gap-2 mt-4">
                    <a href="<?php echo e(route('bicycles.edit', $bicycle->id)); ?>" class="btn btn-warning">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                    <a href="<?php echo e(route('bicycles.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to List
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\01crud\resources\views/bicycles/show.blade.php ENDPATH**/ ?>
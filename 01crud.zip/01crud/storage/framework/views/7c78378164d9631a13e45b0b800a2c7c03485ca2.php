<?php $__env->startSection('title', 'Users Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Users List</h1>
    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> New User
    </a>
</div>

<?php if($users->count() > 0): ?>
    <table class="table table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Country</th>
                <th>Bicycles</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->country->name); ?></td>
                <td><?php echo e($user->bicycles_count); ?></td>
                <td>
                    <div class="btn-group" role="group">
                        <a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-info btn-sm">
                            <i class="fas fa-eye">Show</i>
                        </a>
                        <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit">Edit</i>
                        </a>
                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm"
                                    onclick="return confirm('Delete <?php echo e($user->name); ?>?')">
                                <i class="fas fa-trash">Delete</i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <div class="alert alert-info text-center">
        No users found. <a href="<?php echo e(route('users.create')); ?>">Create first user</a>.
    </div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mt-4">
    <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Back to Home
    </a>
    <span class="text-muted">Total: <?php echo e($users->count()); ?> users</span>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\01crud\resources\views/users/index.blade.php ENDPATH**/ ?>
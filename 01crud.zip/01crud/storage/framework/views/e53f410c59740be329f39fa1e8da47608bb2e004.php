<?php $__env->startSection('title', 'User Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header bg-info text-white">
                <h2 class="mb-0"><i class="fas fa-user"></i> User Details</h2>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>ID:</strong> <?php echo e($user->id); ?></p>
                        <p><strong>Name:</strong> <?php echo e($user->name); ?></p>
                        <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Country:</strong> <?php echo e($user->country->name); ?></p>
                        <p><strong>Bicycles:</strong> <?php echo e($user->bicycles->count()); ?></p>
                        <p><strong>Created:</strong> <?php echo e($user->created_at->format('d/m/Y H:i')); ?></p>
                    </div>
                </div>

                <?php if($user->bicycles->count() > 0): ?>
                <div class="mt-4">
                    <h5>Bicycles:</h5>
                    <ul class="list-group">
                        <?php $__currentLoopData = $user->bicycles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bicycle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <?php echo e($bicycle->brand); ?> <?php echo e($bicycle->model); ?> - <?php echo e($bicycle->color); ?> (€<?php echo e($bicycle->price); ?>)
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <div class="d-flex gap-2 mt-4">
                    <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-warning">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to List
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\01crud\resources\views/users/show.blade.php ENDPATH**/ ?>
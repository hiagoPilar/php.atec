<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Lista de Países</h1>
    <a href="<?php echo e(route('countries.create')); ?>" class="btn btn-primary">Novo País</a>
</div>

<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
           
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($country->id); ?></td>
            <td><?php echo e($country->name); ?></td>

            <td>
                <a href="<?php echo e(route('countries.show', $country->id)); ?>" class="btn btn-info btn-sm">Ver</a>
                <a href="<?php echo e(route('countries.edit', $country->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                <form action="<?php echo e(route('countries.destroy', $country->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm"
                            onclick="return confirm('Tem certeza que deseja excluir este país?')">
                        Excluir
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="d-flex justify-content-between">
    <a href="<?php echo e(route('main')); ?>" class="btn btn-secondary">Voltar ao Início</a>
    <span class="text-muted">Total: <?php echo e($countries->count()); ?> países</span>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\01crud\resources\views/countries/index.blade.php ENDPATH**/ ?>
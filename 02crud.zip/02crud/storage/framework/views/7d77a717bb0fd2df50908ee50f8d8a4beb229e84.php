<?php $__env->startSection('title', 'Editar Escola'); ?>

<?php $__env->startSection('content'); ?>
<h2>Editar Escola</h2>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('schools.update', $school->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label>Nome</label>
        <input type="text" name="name" class="form-control" value="<?php echo e($school->name); ?>" required>
    </div>
    <div class="form-group">
        <label>Cidade</label>
        <input type="text" name="city" class="form-control" value="<?php echo e($school->city); ?>" required>
    </div>
    <button type="submit" class="btn btn-primary mt-2">Atualizar</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\02crud\resources\views/schools/edit.blade.php ENDPATH**/ ?>
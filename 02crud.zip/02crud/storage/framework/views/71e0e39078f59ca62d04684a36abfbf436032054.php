<?php $__env->startSection('title', 'Novo Professor'); ?>

<?php $__env->startSection('content'); ?>
<h2>Novo Professor</h2>

<form method="POST" action="<?php echo e(route('teachers.store')); ?>">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label>Primeiro Nome</label>
        <input type="text" name="first_name" class="form-control" value="<?php echo e(old('first_name')); ?>" required>
    </div>

    <div class="form-group">
        <label>Último Nome</label>
        <input type="text" name="last_name" class="form-control" value="<?php echo e(old('last_name')); ?>" required>
    </div>

    <div class="form-group">
        <label>Data de Contratação</label>
        <input type="date" name="hire_date" class="form-control" value="<?php echo e(old('hire_date')); ?>" required>
    </div>

    <div class="form-group">
        <label>Escola</label>
        <select name="school_id" class="form-control" required>
            <option value="">-- Selecione uma Escola --</option>
            <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($school->id); ?>"><?php echo e($school->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Salvar</button>
    <a href="<?php echo e(route('teachers.index')); ?>" class="btn btn-secondary">Cancelar</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\02crud\resources\views/teachers/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Escolas'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-3">
    <h2>Lista de Escolas</h2>
    <a href="<?php echo e(route('schools.create')); ?>" class="btn btn-primary">Nova Escola</a>
</div>

<form method="GET" class="form-inline mb-3">
    <input type="text" name="search_name" class="form-control mr-2" placeholder="Pesquisar por nome" value="<?php echo e(request('search_name')); ?>">
    <input type="text" name="search_city" class="form-control mr-2" placeholder="Pesquisar por cidade" value="<?php echo e(request('search_city')); ?>">
    <button type="submit" class="btn btn-secondary">Pesquisar</button>
</form>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Nome</th>
            <th>Cidade</th>
            <th>Status</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr <?php if($school->trashed()): ?> class="table-danger" <?php endif; ?>>
            <td><?php echo e($school->name); ?></td>
            <td><?php echo e($school->city); ?></td>
            <td><?php echo e($school->trashed() ? 'Apagada' : 'Ativa'); ?></td>
            <td>
                <?php if(!$school->trashed()): ?>
                    <a href="<?php echo e(route('schools.edit', $school->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                    <form action="<?php echo e(route('schools.destroy', $school->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Apagar escola?')">Apagar</button>
                    </form>
                <?php else: ?>
                    <form action="<?php echo e(route('schools.restore', $school->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-sm btn-success">Restaurar</button>
                    </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($schools->withQueryString()->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\02crud\resources\views/schools/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Teachers'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-3">
    <h2>Lista de Professores</h2>
    <a href="<?php echo e(route('teachers.create')); ?>" class="btn btn-success">+ Novo Professor</a>
</div>

<form method="GET" action="<?php echo e(route('teachers.index')); ?>" class="form-inline mb-3">
    <select name="school_id" class="form-control mr-2">
        <option value="">-- Filtrar por escola --</option>
        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($school->id); ?>" <?php echo e(request('school_id') == $school->id ? 'selected' : ''); ?>>
                <?php echo e($school->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button type="submit" class="btn btn-primary">Filtrar</button>
</form>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Nome</th>
            <th>Escola</th>
            <th>Data de Contratação</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($teacher->first_name); ?> <?php echo e($teacher->last_name); ?></td>
                <td><?php echo e($teacher->school->name ?? '-'); ?></td>
                <td><?php echo e($teacher->hire_date); ?></td>
                <td>
                    <a href="<?php echo e(route('teachers.edit', $teacher->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                    <form action="<?php echo e(route('teachers.destroy', $teacher->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger">Apagar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4">Nenhum professor encontrado.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php echo e($teachers->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\02crud\resources\views/teachers/index.blade.php ENDPATH**/ ?>
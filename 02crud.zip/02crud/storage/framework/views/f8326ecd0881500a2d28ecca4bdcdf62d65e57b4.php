<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Bem-vindo, <?php echo e(Auth::user()->name); ?>!</h1>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\02crud\resources\views/home.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Courses'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-3">
    <h2>Lista de Cursos</h2>
    <a href="<?php echo e(route('courses.create')); ?>" class="btn btn-success">+ Novo Curso</a>
</div>

<form method="GET" action="<?php echo e(route('courses.index')); ?>" class="form-inline mb-3">
    <input type="text" name="category" class="form-control mr-2" placeholder="Filtrar por categoria" value="<?php echo e(request('category')); ?>">

    <select name="teacher_id" class="form-control mr-2">
        <option value="">-- Filtrar por professor --</option>
        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($teacher->id); ?>" <?php echo e(request('teacher_id') == $teacher->id ? 'selected' : ''); ?>>
                <?php echo e($teacher->first_name); ?> <?php echo e($teacher->last_name); ?> (<?php echo e($teacher->school->name ?? '-'); ?>)
            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <button type="submit" class="btn btn-primary">Filtrar</button>
</form>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Título</th>
            <th>Categoria</th>
            <th>Preço (€)</th>
            <th>Professor</th>
            <th>Escola</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($course->title); ?></td>
                <td><?php echo e($course->category); ?></td>
                <td><?php echo e(number_format($course->price, 2, ',', '.')); ?></td>
                <td><?php echo e($course->teacher->first_name); ?> <?php echo e($course->teacher->last_name); ?></td>
                <td><?php echo e($course->teacher->school->name ?? '-'); ?></td>
                <td>
                    <a href="<?php echo e(route('courses.edit', $course->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                    <form action="<?php echo e(route('courses.destroy', $course->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger">Apagar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6">Nenhum curso encontrado.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php echo e($courses->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\02crud\resources\views/courses/index.blade.php ENDPATH**/ ?>
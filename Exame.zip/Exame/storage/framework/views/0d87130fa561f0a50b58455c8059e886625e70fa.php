

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Products List</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Categorie</th>
                    <th>Project</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td>
                        <span class="badge badge-info">
                            <?php echo e($product->categorie->name ?? 'Sem categoria'); ?>

                        </span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('products.show', $product->id)); ?>" 
                        class="btn btn-sm btn-primary">
                        <i class="fas fa-eye"></i> Ver Detalhes
                        </a>
                    </td>
                    <td>
                        <?php echo e($product->project->name ?? 'Sem projeto'); ?>

                    </td>
                    <td>
                        <button class="btn btn-sm btn-primary" data-toggle="modal" 
                                data-target="#detailsModal<?php echo e($product->id); ?>">
                            Show Details
                        </button>
                    </td>
                </tr>
                
                
                <div class="modal fade" id="detailsModal<?php echo e($product->id); ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title"><?php echo e($product->name); ?></h5>
                                <button type="button" class="close" data-dismiss="modal">
                                    <span>&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p><strong>Categorie:</strong> <?php echo e($product->categorie->name); ?></p>
                                <p><strong>Project:</strong> <?php echo e($product->project->name); ?></p>
                                <hr>
                                <p><?php echo e($product->details); ?></p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center">Nenhum produto encontrado</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\Exame\resources\views/pages/products/index.blade.php ENDPATH**/ ?>
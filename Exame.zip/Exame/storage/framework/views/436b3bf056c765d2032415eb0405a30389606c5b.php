

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Projects List</h1>

    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Products</th>
                    <th>Total Products</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($project->id); ?></td>
                    <td><?php echo e($project->name); ?></td>
                    <td>
                        <?php if($project->products->count() > 0): ?>
                            <ul class="list-unstyled">
                                <?php $__currentLoopData = $project->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php echo e($product->name); ?>

                                    <span class="badge badge-info">
                                        <?php echo e($product->category->name ?? 'Sem categoria'); ?>

                                    </span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <span class="text-muted">Nenhum produto associado</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($project->products->count()); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\Exame\resources\views/pages/projects/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>Detalhes do Produto</h2>
    </div>
    <div class="card-body">
        <h3><?php echo e($product->name); ?></h3>
        <p><strong>Categoria:</strong> <?php echo e($product->category->name); ?></p>
        <p><strong>Projeto:</strong> <?php echo e($product->project->name); ?></p>
        <p><strong>Descrição:</strong> <?php echo e($product->details); ?></p>
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Voltar</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\exame02\resources\views/products/show.blade.php ENDPATH**/ ?>
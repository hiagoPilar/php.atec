<div class="text-center mt-5">
    <p>Website by Hiago Pilar using <a href="https://getbootstrap.com/" class="text-primary text-decoration-none">Bootstrap</a></p>
</div><?php /**PATH C:\xampp\htdocs\php.atec\comuna\resources\views/master/footer.blade.php ENDPATH**/ ?>
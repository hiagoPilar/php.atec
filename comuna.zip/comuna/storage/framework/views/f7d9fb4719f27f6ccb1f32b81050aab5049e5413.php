<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title> Comuna </title>
 
    
    <link href="<?php echo asset('css/app.css'); ?>" media="all" rel="stylesheet" type="text/css" />
    <?php echo $__env->yieldContent('styles'); ?>
    
</head>
<body>
 

<?php $__env->startComponent('master.header'); ?>
<?php if (isset($__componentOriginal661375f12d1c5a73f2f163e0562459069f6d7e6e)): ?>
<?php $component = $__componentOriginal661375f12d1c5a73f2f163e0562459069f6d7e6e; ?>
<?php unset($__componentOriginal661375f12d1c5a73f2f163e0562459069f6d7e6e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

 

<main>
    <?php echo $__env->yieldContent('content'); ?>
    <img src="<?php echo e(asset('img/comunistas.jpeg')); ?>" class="img-fluid banner-img" style="width: 100%; height: 800px;" alt="Comunistas">

    <div class="container mt-4">
        <div class="row text-center">
            <div class="col-md-4 figuras">
                <img src="<?php echo e(asset('img/marx.jpg')); ?>" alt="Karl Marx" class="img-fluid mb-2">
                <h2>Karl Marx</h2>
                <p>Karl Marx foi um filósofo, economista e sociólogo alemão, conhecido por ser um dos fundadores do socialismo científico.</p>
                <a href="" class="btn btn-primary">Saiba mais</a>
            </div>
            <div class="col-md-4 figuras">
                <img src="<?php echo e(asset('img/lenin.jpg')); ?>" alt="Vladimir Lenin" class="img-fluid mb-2">
                <h2>Vladimir Lenin</h2>
                <p>Vladimir Lenin foi um revolucionário e político russo, líder da Revolução de Outubro e fundador do Estado soviético.</p>
                <a href="" class="btn btn-primary">Saiba mais</a>
            </div>
            <div class="col-md-4 figuras">
                <img src="<?php echo e(asset('img/kollontai.jpg')); ?>" alt="Alexandra Kollontai" class="img-fluid mb-2">
                <h2>Alexandra Kollontai</h2>
                <p>Alexandra Kollontai foi uma revolucionária e política russa, conhecida por seu trabalho em prol dos direitos das mulheres e sua atuação no governo soviético.</p>
                <a href="" class="btn btn-primary">Saiba mais</a>
            </div>
        </div>
    </div>



    <section class="russa">
        <div class="container mt-4">
            <div class="row align-items-center">
                <div class="col-md-6 figuras2 d-flex flex-column justify-content-center align-items-center">
                    <h2>Revolução Russa</h2>
                    <p class="text-center">A Revolução Russa de 1917 foi um marco na história, resultando na queda do Império Russo e na ascensão do socialismo e da classe trabalhadora.</p>
                </div>
                <div class="col-md-6 figuras2 d-flex justify-content-center align-items-center">
                    <img src="<?php echo e(asset('img/russia.jpg')); ?>" alt="Revolução Russa" class="img-fluid mb-2">
                </div>
            </div>
        </div>
    </section>

    <section class="china">
        <div class="container mt-4">
            <div class="row align-items-center">
                <div class="col-md-6 figuras2 d-flex justify-content-center align-items-center">
                    <img src="<?php echo e(asset('img/china.jpeg')); ?>" alt="Revolução Chinesa" class="img-fluid mb-2">
                </div>
                <div class="col-md-6 figuras2 d-flex flex-column justify-content-center align-items-center">
                    <h2>Revolução Chinesa</h2>
                    <p class="text-center">A Revolução Chinesa de 1949 foi um marco na história, resultando na queda do governo nacionalista e na ascensão do socialismo na China.</p>
                </div>
            </div>
        </div>
    </section>
   


</main>
 

 
<?php $__env->startComponent('master.footer'); ?>
<?php if (isset($__componentOriginald05ce9d8d01af187aa2403d4e02ae189359a481e)): ?>
<?php $component = $__componentOriginald05ce9d8d01af187aa2403d4e02ae189359a481e; ?>
<?php unset($__componentOriginald05ce9d8d01af187aa2403d4e02ae189359a481e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
 
<script src="<?php echo asset('js/app.js'); ?>" type="text/javascript"></script>
<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\php.atec\comuna\resources\views//master/main.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<img src="https://luansperandio.com/fatos-comunismo/" class="img-fluid" alt="Comunistas"> 


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\comuna\resources\views/home.blade.php ENDPATH**/ ?>
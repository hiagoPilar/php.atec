
<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title> Comuna </title>
 
    
    <link href="<?php echo asset('css/app.css'); ?>" media="all" rel="stylesheet" type="text/css" />
    <?php echo $__env->yieldContent('styles'); ?>
    

    <style>
        main {
            background-color: antiquewhite;
        }
    </style>
</head>
<body>
 

<?php $__env->startComponent('master.header'); ?>
<?php if (isset($__componentOriginal661375f12d1c5a73f2f163e0562459069f6d7e6e)): ?>
<?php $component = $__componentOriginal661375f12d1c5a73f2f163e0562459069f6d7e6e; ?>
<?php unset($__componentOriginal661375f12d1c5a73f2f163e0562459069f6d7e6e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

 

<main>
    <?php echo $__env->yieldContent('content'); ?>

    
    <section>
        <div class="container mt-4">
            <div class="row text-center">
                <div class="col-md-12">
                    <h1>Galeria de Heróis Revolucionários</h1>
                    <p>Explore as vidas e legados de figuras icônicas que moldaram a história.</p>
                </div>
            </div>
        </div>
    </section>
    
    
    
    <div class="container mt-4">
        <div class="row text-center">
            
            <div class="col-md-4 figuras">
                <img src="<?php echo e(asset('img/imgs/che.jpg')); ?>" alt="Che Guevara" class="img-fluid mb-2">
            </div>
            <div class="col-md-4 figuras">
                <img src="<?php echo e(asset('img/imgs/rosa.jpg')); ?>" alt="Rosa Luxenburgo" class="img-fluid mb-2">
                
            </div>
            <div class="col-md-4 figuras">
                <img src="<?php echo e(asset('img/imgs/engels.jpg')); ?>" alt="Friedrich Engels" class="img-fluid mb-2">

            </div>
        </div>
    </div>

     <div class="container mt-4">
        <div class="row text-center">
            
            <div class="col-md-4 figuras">
                <img src="<?php echo e(asset('img/imgs/mao.jpg')); ?>" alt="Mao Zedong" class="img-fluid mb-2">
            </div>
            <div class="col-md-4 figuras">
                <img src="<?php echo e(asset('img/imgs/angela.jpg')); ?>" alt="Angela Davis" class="img-fluid mb-2">

            </div>
            <div class="col-md-4 figuras">
                <img src="<?php echo e(asset('img/imgs/fidel.jpg')); ?>" alt="Fidel Castro" class="img-fluid mb-2">

            </div>
        </div>
    </div>
   


</main>
 

 
<?php $__env->startComponent('master.footer'); ?>
<?php if (isset($__componentOriginald05ce9d8d01af187aa2403d4e02ae189359a481e)): ?>
<?php $component = $__componentOriginald05ce9d8d01af187aa2403d4e02ae189359a481e; ?>
<?php unset($__componentOriginald05ce9d8d01af187aa2403d4e02ae189359a481e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
 
<script src="<?php echo asset('js/app.js'); ?>" type="text/javascript"></script>
<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\php.atec\comuna\resources\views/components/gallery/gallery.blade.php ENDPATH**/ ?>
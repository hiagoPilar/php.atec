

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1>Bicycles List</h1>
    
    

    <?php if($bicycles->isNotEmpty()): ?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Brand</th>
                <th>Color</th>
                <th>Preço</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bicycles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bicycle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($bicycle->brand); ?></td>
                <td><?php echo e($bicycle->color); ?></td>
                <td><?php echo e($bicycle->price); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <div class="alert alert-warning">Nenhuma bicicleta encontrado</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\review\resources\views/components/bicycles/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<div class="d-grid gap-2 d-md-flex justify-content-md-center">
     <a class="btn btn-success" role="button" href="<?php echo e(url('players/create')); ?>" >Adicionar novo player</a>
 </div>

<h1>Players List</h1>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Address</th>
      <th scope="col">Retired</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
    <tr>
      <th scope="row"><?php echo e($player->id); ?></th>
      <td><?php echo e($player->name); ?></td>
      <td><?php echo e($player->address); ?></td>
      <td><?php echo e($player->retired); ?></td>
      <td>
        <button type="button" class="btn btn-success">Show</button>
        <button type="button" class="btn btn-primary">Edit</button>
        <button type="button" class="btn btn-danger">Delete</button>
      </td>
    </tr>
  </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\Player\resources\views/components/players/players-list.blade.php ENDPATH**/ ?>
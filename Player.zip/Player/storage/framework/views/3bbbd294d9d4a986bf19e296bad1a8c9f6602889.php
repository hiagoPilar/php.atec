
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('components.players.players-list', ['players' => $players]); ?>
<?php if (isset($__componentOriginal7b4d754d1e47828f9a7daf2fb87d49e7f6ba29dc)): ?>
<?php $component = $__componentOriginal7b4d754d1e47828f9a7daf2fb87d49e7f6ba29dc; ?>
<?php unset($__componentOriginal7b4d754d1e47828f9a7daf2fb87d49e7f6ba29dc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\Player\resources\views/pages/players/index.blade.php ENDPATH**/ ?>
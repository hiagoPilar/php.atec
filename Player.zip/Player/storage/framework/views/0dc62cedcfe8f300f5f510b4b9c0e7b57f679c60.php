<h1>Players List</h1>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Address</th>
      <th scope="col">Retired</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
    <tr>
      <th scope="row"><?php echo e($player->id); ?></th>
      <td><?php echo e($player->name); ?></td>
      <td><?php echo e($player->address); ?></td>
      <td><?php echo e($player->retired); ?></td>
      <td>
        <button type="button" class="btn btn-success">Show</button>
        <button type="button" class="btn btn-primary">Edit</button>
        <button type="button" class="btn btn-danger">Delete</button>
      </td>
    </tr>
  </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\xampp\htdocs\php.atec\site002\resources\views/components/players/players-list.blade.php ENDPATH**/ ?>
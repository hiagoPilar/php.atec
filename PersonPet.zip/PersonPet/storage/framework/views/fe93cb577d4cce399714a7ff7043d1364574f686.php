<h1>Person List</h1>
<table class="table">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">Name</th>
        <th scope="col">Birthdate</th>
        <th scope="col">Email</th>
        <th scope="col">Actions</th>
    </tr>
    </thead>
    <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
        <tr>
            <th scope="row"><?php echo e($person->id); ?></th>
            <td><?php echo e($person->name); ?></td>
            <td><?php echo e($person->birthdate); ?></td>
            <td><?php echo e($person->email); ?></td>
            <td>
                <button type="button" class="btn btn-success">Show</button>
                <button type="button" class="btn btn-primary">Edit</button>
                <button type="button" class="btn btn-danger">Delete</button>
            </td>
        </tr>
        </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\xampp\htdocs\php.atec\PersonPet\resources\views/components/persons/person-list.blade.php ENDPATH**/ ?>
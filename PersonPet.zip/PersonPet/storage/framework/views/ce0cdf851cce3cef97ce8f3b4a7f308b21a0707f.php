

<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.persons.person-list', ['persons' => $persons]); ?>
<?php if (isset($__componentOriginal1fd2ebdad55574a3a27e35bfb19e097ee206e3a2)): ?>
<?php $component = $__componentOriginal1fd2ebdad55574a3a27e35bfb19e097ee206e3a2; ?>
<?php unset($__componentOriginal1fd2ebdad55574a3a27e35bfb19e097ee206e3a2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php.atec\PersonPet\resources\views/pages/persons/index.blade.php ENDPATH**/ ?>
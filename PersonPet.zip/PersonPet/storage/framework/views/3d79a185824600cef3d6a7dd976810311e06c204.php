<h1>Pet List</h1>
<table class="table">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">Name</th>
        <th scope="col">Color</th>
        <th scope="col">Birthdate</th>
        <th scope="col">Actions</th>
    </tr>
    </thead>
    <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
        <tr>
            <th scope="row"><?php echo e($pet->id); ?></th>
            <td><?php echo e($pet->name); ?></td>
            <td><?php echo e($pet->color); ?></td>
            <td><?php echo e($pet->birthdate); ?></td>
            <td>
                <button type="button" class="btn btn-success">Show</button>
                <button type="button" class="btn btn-primary">Edit</button>
                <button type="button" class="btn btn-danger">Delete</button>
            </td>
        </tr>
        </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\xampp\htdocs\php.atec\PersonPet\resources\views/components/pets/pets-list.blade.php ENDPATH**/ ?>